import java.io.*;
import java.net.*;
import com.sun.nio.sctp.*;
import java.util.*;
import java.nio.*;
public class sctpClient 
{
	public static final int MESSAGE_SIZE = 100;
	public static HashMap<Integer,String> h1 = new HashMap<Integer,String>();
	public void go()
	{
		//Buffer to hold messages in byte format
		ByteBuffer byteBuffer = ByteBuffer.allocate(MESSAGE_SIZE);
		String message = "Hello from client";
		try
		{
			//Create a socket address for  server at net01 at port 5000
			SocketAddress socketAddress = new InetSocketAddress("net01.utdallas.edu",5000);
			//Open a channel. NOT SERVER CHANNEL
			SctpChannel sctpChannel = SctpChannel.open();
			//Bind the channel's socket to a local port. Again this is not a server bind
			sctpChannel.bind(new InetSocketAddress(5000));
			//Connect the channel's socket to  the remote server
			sctpChannel.connect(socketAddress);
			//Before sending messages add additional information about the message
			MessageInfo messageInfo = MessageInfo.createOutgoing(null,0);
			//convert the string message into bytes and put it in the byte buffer
			byteBuffer.put(message.getBytes());
			//Reset a pointer to point to the start of buffer 
			byteBuffer.flip();
			//Send a message in the channel (byte format)
			sctpChannel.send(byteBuffer,messageInfo);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	public static void main(String args[])
	{
		sctpClient SctpClientObj = new sctpClient();
		try{
			FileInputStream fstream = new FileInputStream("confifr.txt");
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//Read File Line By Line
/*			while ((strLine = br.readLine()) != null)   {
				// Print the content on the console
				//System.out.println (strLine);
				if(!(strLine.startsWith("#"))){
					String[] tokens = strLine.split("#");
					String tempToken = tokens[0].trim();
					//System.out.println(tempToken);
					if(!(tempToken.startsWith("("))&&(tempToken.contains(" "))){
						String[] SecondToken = tempToken.split(" ");
						if((SecondToken[1].length()!=0)){
							String ipaddress = SecondToken[1];
								int portno       = Integer.parseInt(SecondToken[2]);
							System.out.println(ipaddress+":"+portno); 
						}
					} 
				} 
			} */
			
			while ((strLine = br.readLine())!= null) {

				String[] tokens = strLine.split(",");
				int serialno = Integer.parseInt(tokens[0]);
				String value = tokens[1];
				h1.put(serialno, value);

				//System.out.println(h1);
				printMap(h1);
				}
 			//Close the input stream
			in.close();
		}catch(Exception e){
			e.printStackTrace();
		}

		//SctpClientObj.go();
	}
	
	public static void printMap(Map mp) {
	    Iterator it = mp.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pairs = (Map.Entry)it.next();
	        System.out.println(pairs.getKey() + " = " + pairs.getValue());
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	}
}